1. Make changes in non-functional requirements at part 6.
2. Remove part tournament mode feature in part 5.A.
3. Convert all to pdf.